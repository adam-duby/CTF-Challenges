# Buggy script students must fix
print("Your token is: RED42TOKEN"
