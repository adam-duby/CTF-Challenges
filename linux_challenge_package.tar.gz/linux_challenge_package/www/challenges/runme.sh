#!/bin/bash

echo "Your token is: BLUE42TOKEN"
